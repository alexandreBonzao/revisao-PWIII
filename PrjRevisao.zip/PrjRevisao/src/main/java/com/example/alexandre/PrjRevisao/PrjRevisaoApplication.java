package com.example.alexandre.PrjRevisao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrjRevisaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrjRevisaoApplication.class, args);
	}

}
