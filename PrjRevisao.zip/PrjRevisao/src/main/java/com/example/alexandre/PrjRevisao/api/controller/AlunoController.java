package com.example.alexandre.PrjRevisao.api.controller;

import com.example.alexandre.PrjRevisao.domain.repository.AlunoRepository;
import com.example.alexandre.PrjRevisao.domain.service.AlunoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/alunos")
public class AlunoController {

    @Autowired
    private AlunoRepository alunoRepository;

    @Autowired
    private AlunoService alunoService;


}
