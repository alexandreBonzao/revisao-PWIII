package com.example.alexandre.PrjRevisao.domain.exception;

public class EntidadeEmUsoException extends RuntimeException{
    public EntidadeEmUsoException (String mensagem) {super(mensagem);}
}
