package com.example.alexandre.PrjRevisao.domain.exception;

public class EntidadeNaoEncontradaExcenption extends RuntimeException{
    public EntidadeNaoEncontradaExcenption(String mensagem){super(mensagem);}
}
