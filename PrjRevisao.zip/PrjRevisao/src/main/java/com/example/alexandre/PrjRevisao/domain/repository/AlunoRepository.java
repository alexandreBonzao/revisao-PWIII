package com.example.alexandre.PrjRevisao.domain.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface AlunoRepository extends JpaRepository<Aluno, Long> {

}
