package com.example.alexandre.PrjRevisao.domain.service;

import com.example.alexandre.PrjRevisao.domain.repository.AlunoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AlunoService {

    @Autowired
    private AlunoRepository alunoRepository;
}
