package com.example.alexandre.PrjRevisao.domain.service;

import com.example.alexandre.PrjRevisao.domain.exception.EntidadeEmUsoException;
import com.example.alexandre.PrjRevisao.domain.exception.EntidadeNaoEncontradaExcenption;
import com.example.alexandre.PrjRevisao.domain.model.Aluno;
import com.example.alexandre.PrjRevisao.domain.repository.AlunoRepository;
import org.hibernate.action.internal.EntityActionVetoException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

@Service
public class AlunoService {

    @Autowired
    private AlunoRepository alunoRepository;

    public Aluno salvar (Aluno aluno) { return alunoRepository.save(aluno);}

    public void excluir(Long id){
        try {
            alunoRepository.deleteById(id);
        } catch (DataIntegrityViolationException e){
            throw new EntidadeEmUsoException(String.format("ALuno ou código %d não pode ser reovida, pois esta em uso.",id));
        } catch (EmptyResultDataAccessException e){
            throw new EntidadeNaoEncontradaExcenption(String.format("Não existe cadastro do aluno em código %d",id));
        }
    }
}
