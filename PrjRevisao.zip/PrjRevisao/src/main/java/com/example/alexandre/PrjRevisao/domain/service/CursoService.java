package com.example.alexandre.PrjRevisao.domain.service;

import com.example.alexandre.PrjRevisao.domain.exception.EntidadeEmUsoException;
import com.example.alexandre.PrjRevisao.domain.exception.EntidadeNaoEncontradaExcenption;
import com.example.alexandre.PrjRevisao.domain.model.Curso;
import com.example.alexandre.PrjRevisao.domain.repository.CursoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

@Service
public class CursoService {

    @Autowired
    private CursoRepository cursoRepository;

    public Curso salvar (Curso curso) {return cursoRepository.save(curso);}

    public void excluir(Long id){
        try {
            cursoRepository.deleteById(id);
        } catch (DataIntegrityViolationException e){
            throw new EntidadeEmUsoException(String.format("Curso ou código %d não pode ser reovida, pois esta em uso.",id));
        } catch (EmptyResultDataAccessException e){
            throw new EntidadeNaoEncontradaExcenption(String.format("Não existe cadastro do curso em código %d",id));
        }
    }
}
