create table tb_aluno(
    id biging not null auto_increment;
    nome_aluno VARCHAR(100),
    curso_id bigint not null,

    primary key(id)
)engine=InnoDB default charset=utf8;
