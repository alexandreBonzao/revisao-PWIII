package com.example.alexandre.PrjRevisao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrjRevisaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
